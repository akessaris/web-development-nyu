<!DOCTYPE html>

<html>
  <head>
    <title>Caculator</title>
    <meta charset="utf-8">
  </head>

 <body>

<?php

$num1 = $_POST("#num1");
$num2 =	$_POST("#num2");

$operator = $_POST(".operator");

printf($operator . " " . $operator.val);

?>

 </body>

</html>
